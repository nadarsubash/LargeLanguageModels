#FastAPI Packages
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import shutil
import json 

#OpenAI packages
import PyPDF2
import gradio as gr
import os
from dotenv import load_dotenv
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.chains import LLMChain

os.environ['OPENAI_API_KEY'] = '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'

load_dotenv()

# Get OpenAI API key from environment variable
openai_api_key = os.getenv('OPENAI_API_KEY')

# Check if API key is loaded
if not openai_api_key:
    raise ValueError("OpenAI API key is missing")

app = FastAPI()

# CORS middleware to allow front-end to communicate with the back-end
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this to the specific origins allowed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount the static files directory to serve the HTML
app.mount("/static", StaticFiles(directory="static"), name="static")

# Directory where uploaded files will be saved
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


## MAIN PROCESSING==========================================


def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        num_pages = len(reader.pages)
        for page_num in range(num_pages):
            page = reader.pages[page_num]
            text += page.extract_text()
    return text


# # STEP 03: Mapping to Schema
# schema_path = "/Users/subashnadar/Documents/Code_Base/NLD/NLD.AI.Code/Data-New/Floralinc_schema_v1.txt"
schema_path = "Floralinc_schema_v1.txt"

with open(schema_path, 'r') as file:
    # Read the content of the file
    schema_1 = file.read()


# PROMPT TEMPLATE V2 (floralinc)
template = ChatPromptTemplate.from_messages([
    ("system", """You are a specialist in comprehending Invoices. 
     Input Text from invoice will be provided to you, and your task is to 
     respond to instructions based on the content of the input invoice text. 
     About Invoice Format: 
     1. Header - it has Invoice, Buyer and Seller details. This is common on every page of the document.
     2. First Table - it has description, code, price etc.
     3. Second Table - it has descriptions, weights, amount and value. 
     """),
    ("user", """
        Invoice Context: {context_invoice}
        From the invoice context provided, extract the key-value pairs and table information. 
        Ignore the First table information, as they are not relevant to the user.
        Now map the key-value pairs and table information to the below fields in the schema with corresponding values, where you see relevant mapping
        Schema: {schema_1}
        
        Write the output in Pretty JSON format
    """
    )
])

def map_to_schema(template, context_invoice, schema_1):

    print("inside map to schema\n")
    # model_infer = "gpt-3.5-turbo-0125"
    model_infer = "gpt-4o-mini"

    # Initialize the OpenAI chat model with the model
    llm = ChatOpenAI(api_key=openai_api_key, 
                     model_name=model_infer, 
                     temperature=0, 
                     max_tokens=2000)

    # Create an LLMChain object with the chat model and the prompt template
    chain = LLMChain(llm=llm, prompt=template)

    parameters = {
    "context_invoice": context_invoice,
    "schema_1": schema_1
    }

    # Generate the response using the chain
    response = chain.run(parameters)

    return response


def process_pdf(file_path: str):
    print("Type of the pdf path from gradio: ", file_path)
    context_invoice = extract_text_from_pdf(file_path)
    print("just completed extract pdf step\n\n")
    output_schema = map_to_schema(template, context_invoice, schema_1)
    return output_schema

#==========================================


@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    # Process the PDF file using the existing function
    json_data = process_pdf(file_path)
    
    #OLD CODE========
    # return JSONResponse(content=json_data)
    
    #NEW CODE========
    # Convert the JSON data to a pretty-printed string format
    pretty_json = json.dumps(json_data, indent=2)
    
    return JSONResponse(content=json.loads(pretty_json))

# Start the FastAPI app using Uvicorn
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
